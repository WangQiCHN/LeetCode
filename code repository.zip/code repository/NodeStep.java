package first;
public class NodeStep {
    public int current;
    public int least;

    public NodeStep(int current, int least) {
        this.current = current;
        this.least = least;
    }
}
