import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

class Solution {
    void main() {
        String s = "barfoothefoobarman";
        String[] words = {"foo", "bar"};
        List<Integer> result = findSubstring(s, words);
        for (int r : result) {
            System.out.println(r);
        }
    }
    private List<Integer> result = new ArrayList<>();
    public List<Integer> findSubstring(String s, String[] words) {
        int[] windows = new int[26];
        int condition = 0;
        int size = words.length * words[0].length();
        Map<String, Integer> ratio = new HashMap<>();
        for (String w : words) {
            char[] cw = w.toCharArray();
            for (int i = 0; i < cw.length; i++) {
                char c = cw[i];
                windows[c - 'a']++;
            }
            if (ratio.containsKey(w)) {
                int v = ratio.get(w);
                ratio.put(w, v + 1);
            } else {
                ratio.put(w, 1);
            }
        }
        for (int w : windows) {
            if (w > 0) condition++;
        }

        int left = 0, right = 0;
        while (right < s.length()) {
            char c = s.charAt(right);
            right++;
            windows[c - 'a']--;
            if (windows[c - 'a'] == 0) {
                condition--;
                if (condition == 0) {
                    testWords(s, left, right, words[0].length(), ratio);
                }
            } else if (windows[c - 'a'] == -1) {
                condition++;
            }

            if (right - left == size) {
                c = s.charAt(left);
                left++;
                windows[c - 'a']++;
                if (windows[c - 'a'] == 0) {
                    condition--;
                } else if (windows[c - 'a'] == 1) {
                    condition--;
                }
            }
        }

        return result;
    }

    private void testWords(String s, int left, int right, int length, Map<String, Integer> ratio) {
        Map<String, Integer> compare = new HashMap<>();
        int index = left;
        while (left < right) {
            String ns = s.substring(left, left + length);
            if (compare.containsKey(ns)) {
                int v = compare.get(ns);
                compare.put(ns, v + 1);
            } else {
                compare.put(ns, 1);
            }
            left += length;
        }

        Iterator<String> keys = ratio.keySet().iterator();
        while (keys.hasNext()) {
            String key = keys.next();
            Integer v1 = ratio.get(key);
            Integer v2 = compare.get(key);

            if (v2 == null) return;
            if (v1.intValue() == v2.intValue()) continue;
            else return;
        }

        result.add(index);
    }
}