## 我不希望调用调试，错了就重来，看看结果







| Index. | No. | Name | Result. |
|:-------|:----|------|---------|
| ~~1.~~ | 3 | **~~Longest Substring Without Repeating Characters~~** |    |
| ~~2.~~ | 5 | **~~Longest Palindromic Substring~~** |    |
| ~~3.~~ | 10 | **~~Regular Expression Matching~~** |    |
| ~~4.~~ | 11 | **~~Container With Most Water~~** |    |
| ~~5.~~ | 15 | **~~3Sum~~** |    |
| ~~6.~~ | 18 | **~~4Sum~~** |    |
| ~~7.~~ | 19 | **~~Remove Nth Node From End of List~~** |    |
| ~~8.~~ | 21 | **~~Merge Two Sorted Lists~~** |    |
| ~~9.~~ | 23 | **~~Merge K Sorted Lists~~** |    |
| ~~10.~~| 26 | **~~Remove Duplicates from Sorted Array~~** |    |
| ~~11.~~| 27 | **~~Remove Element~~** |    |
| ~~12.~~| 34 | **~~Find First and Last Position of Element in Sorted Array~~** |    |
| ~~13.~~| 39 | **~~Combination Sum~~** |    |
| ~~14.~~| 40 | **~~Combination Sum II~~** |    |
| ~~15.~~| 42 | **~~Trapping Rain Water~~** |    |
| ~~16.~~| 46 | **~~Permutations~~** |    |
| ~~17.~~| 47 | **~~Permutations II~~** |    |
| ~~18.~~| 51 | **~~N-Queens~~** |    |
| ~~19.~~| 53 | **~~Maximum Subarray~~** |    |
| ~~20.~~| 64 | **~~Minimum Path Sum~~** |    |
| ~~21.~~| 72 | **~~Edit Distance~~** |    |
| ~~22.~~| 76 | **~~Minimum Window Substring~~** |    |
| ~~23.~~| 77 | **~~Combinations~~** |    |
| ~~24.~~| 78 | **~~Subsets~~** |    |
| ~~25.~~| 83 | **~~Remove Duplicates from Sorted List~~** |    |
| ~~26.~~| 90 | **~~Subsets II~~** |    |
| ~~27.~~| 92 | **~~Reverse Linked List II~~** | 还是不太熟悉！，换了思路，果然好了很多   |
| ~~28.~~| 98 | **~~Validate Binary Search Tree~~** |    |
| ~~29.~~| 104 | **~~Maximum Depth of Binary Tree~~** |    |
| ~~30.~~| 105 | **~~Construct Binary Tree from Preorder and Inorder~~** |    |
| ~~31.~~| 106 | **~~Construct Binary Tree from Inorder and Postorder~~** |    |
| ~~32.~~| 111 | **~~Minimum Depth of Binary Tree~~** |    |
| ~~33.~~| 114 | **~~Flatten binary Tree to Linked List~~** |    |
| ~~34.~~| 116 | **~~Populating Next Right Pointers in Each Node~~** |    |
| ~~35.~~| 130 | **~~Surrounded Regions~~** |    |
| ~~36.~~| 141 | **~~Linked List Cycle~~** |    |
| ~~37.~~| 142 | **~~Linked List Cycle II~~** |    |
| ~~38.~~| 144 | **~~Binary Tree Preorder Traversal~~** |    |
| ~~39.~~| 146 | **~~LRU Cache~~** |    |
| ~~40.~~| 160 | **~~Intersection of Two Linked Lists~~** |    |
| ~~41.~~| 167 | **~~Two Sum II - Input Array Is Sorted~~** |    |
| ~~42.~~| 174 | **~~Dungeon Game~~** |    |
| ~~43.~~| 200 | **~~Number of Islands~~** |    |
| ~~44.~~| 206 | **~~Reverse Linked List~~** |    |
| ~~45.~~| 215 | **~~Kth Largest Element in an Array~~** | 失败了！需要用更好的思路，否则超时了，这个思路好，起码保证了第一个数不会无法交换 |
| ~~46.~~| 226 | **~~Invert Binary Tree~~** |    |
| ~~47.~~| 230 | **~~Kth Smallest Element in a BST~~** |    |
| ~~48.~~| 235 | **~~Lowest Common Ancestor of a Binary Search Tree~~** |    |
| ~~49~~ | 236 | **~~Lowest Common Ancestor of a Binary Tree~~** |    |
| ~~50.~~| 239 | **~~Sliding Window Maximum~~** |    |
| ~~51.~~| 261 plus | **~~Graph Valid Tree~~** |   |
| ~~52.~~| 283 | **~~Move Zeroes~~** |    |
| ~~53.~~| 297 | **~~Serialize and Deserialize Binary Tree~~** |    |
| ~~54.~~| 300 | **~~Longest Increasing Subsequence~~** |    |
| ~~55.~~| 303 | **~~Range Sum Query - Immutable~~** |    |
| ~~56.~~| 304 | **~~Range Sum Query 2D - Immutable~~** |    |
| ~~57.~~| 312 | **~~Burst Balloons~~** |    |
| ~~58.~~| 315 | **~~Count of Smaller Numbers After Self~~** |    |
| ~~59.~~| 316 | **~~Remove Duplicate Letters~~** |    |
| ~~60.~~| 322 | **~~Coin Change~~** |    |
| ~~61.~~| 323 plus | **~~Number of Connected Components in an Undirected Graph~~** | 唯一要注意的就是findParent，其实使用sizes会更好 |
| ~~63.~~| 344 | **~~Reverse String~~** |    |
| ~~64.~~| 354 | **~~Russian Doll Envelopes~~** |    |
| ~~64.~~| 370 plus | **~~Range Addition~~** |    |
| ~~65.~~| 380 | **~~Insert Delete GetRandom O(1)~~** |    |
| ~~66.~~| 410 | **~~Split Array Largest Sum~~** |    |
| ~~67.~~| 416 | **~~Partition Equal Subset Sum~~** |    |
| ~~68.~~| 438 | **~~Find All Anagrams in a String~~** |    |
| ~~69.~~| 450 | **~~Delete Node in a BST~~** |    |
| ~~70.~~| 460 | **~~LFU Cache~~** |    |
| ~~71.~~| 496 | **~~Next Greater Element I~~** |    |
| ~~72.~~| 503 | **~~Next Greater Element II~~** |    |
| ~~73.~~| 509 | **~~Fibonacci Number~~** |  | 
| ~~74.~~| 516 | **~~Longest Palindromic Subsequence~~** | 这个可以再巩固一下！我擦，很成功   |
| ~~75.~~| 518 | **~~Coin Change II~~** |    |
| ~~76.~~| 528 | **~~Random Pick with Weights~~** | 再用double试一下，虽然过了，但是在0的时候，是有问题的，还是用整数吧    |
| ~~77.~~| 538 | **~~Convert BST to Greater Tree~~** |    |
| ~~78.~~| 543 | **~~Diameter of Binary Tree~~** |    |
| ~~79.~~| 567 | **~~Permutation is String~~** |    |
| ~~80.~~| 583 | **~~Delete Operation for Two Strings~~** | 用背包问题再解决一下，搞定了   |
| ~~81.~~| 654 | **~~Maximum Binary Tree~~** |    |
| ~~82.~~| 694 plus | **~~Number of Distinct Islands~~** |    |
| ~~83.~~| 695 | **~~Max Area of Island~~** |    |
| ~~84.~~| 698 | **~~Partition to K Equal Sum Subsets~~** | 看一下如何有更好的方案，之前那个太烦了，没有了，就这样了    |
| ~~85.~~| 700 | **~~Search in a Binary Search Tree~~** |    |
| ~~86.~~| 701 | **~~Insert into a Binary Search Tree~~** |    |
| ~~87.~~| 704 | **~~Binary Search~~** |    |
| ~~88.~~| 710 | **~~Random Pick with Blacklist~~** |    |
| ~~89.~~| 712 | **~~Minimum ASCII Delete Sum for Two Strings~~** | 又是一道背包题，搞定了，就是583啊   |
| ~~90.~~| 739 | **~~Daily Temperatures~~** |    |
| ~~91.~~| 752 | **~~Open the Lock~~** |    |
| ~~92.~~| 773 | **~~Sliding Puzzle~~** |    |
| ~~93.~~| 797 | **~~All Paths From Source to Target~~** |    |
| ~~94.~~| 870 | **~~Advantage Shuffle~~** |    |
| ~~95.~~| 875 | **~~Koko Eating Bananas~~** |    |
| ~~96.~~| 876 | **~~Middle of the Linked List~~** |    |
| ~~97.~~| 887 | **~~Super Egg Drop~~** | 尝试普通的背包方式，三层，搞定   |
| ~~98.~~| 889 | **~~Construct Binary Tree from Preorder and Postorder~~** |    |
| ~~99.~~| 912 | **~~Sort an Array~~** | 看来快速排序，还是不大熟悉啊，可以了   |
| ~~100.~~| 931 | **~~Minimum Falling Path Sum~~** |    |
| ~~101.~~| 990 | **~~Satisfiability of Equality Equations~~** |    |
| ~~102.~~| 1011 | **~~Capacity To Ship Packages Within D Days~~** |    |
| ~~103.~~| 1020 | **~~Number of Enclaves~~** |    |
| ~~104.~~| 1094 | **~~Car Pooling~~** |    |
| ~~105.~~| 1109 | **~~Corporate Flight Bookings~~** |    |
| ~~106.~~| 1135 plus | **~~Connecting Cities With Minimum Cost~~** |    |
| ~~107.~~| 1143 | **~~Longest Common Subsequence~~** | 这个和1312其实一样，看看，搞定了   |
| ~~108.~~| 1254 | **~~Number of Closed Islands~~** |    |
| ~~109.~~| 1312 | **~~Minimum Insertion Steps to Make a String Palindrome~~** | 在背包试试，这个基本对了，516的对称题   |
| ~~110.~~| 1584 | **~~Min Cost to Connect All Points~~** |    |
| ~~111.~~| 1644 plus | **~~Lowest Common Ancestor of a Binary Tree II~~** |    |
| ~~112.~~| 1650 plus | **~~Lowest Common Ancestor of a Binary Tree III~~** |    |
| ~~113.~~| 1676 plus | **~~Lowest Common Ancestor of a Binary Tree IV~~** |    |
| ~~114.~~| 1905 | **~~Count Sub Islands~~** |    |